﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PLearning_Backend.Enumerations
{
    enum DataType
    {
        Int,
        Float,
        String,
        Bool,
        Char
    }

    enum ReturnType
    {
        Int,
        Float,
        String,
        Bool,
        Char,
        Void,
        Program,
        Main
    }

    

}
